from django.contrib import admin
from autotest.models import User

# Register your models here.


admin.site.register(User)